from django.contrib import admin
from .models import moodle
# Register your models here.
admin.site.register(moodle)